LOCATORS = {
    'exec_path': "/home/basha/Downloads/chromedriver",
    'url': 'https://opensource-demo.orangehrmlive.com/index.php/dashboard',
    'user': 'Admin',
    'pwd': 'admin123',
    'user_id': 'txtUsername',
    'pwd_id': 'txtPassword',
    'login_id': 'Submit'
}
