data = {
    "url" : "https://opensource-demo.orangehrmlive.com/index.php/auth/validateCredentials",
    "username": "Admin",
    "password": "admin123"
}