loc = {
    "username": "username",
    "password": "password",
    "login_btn": '//button[@type="submit"]',
    "myinfo_link": '//a[@href="/web/index.php/pim/viewMyDetails"]'
}

dash_loc = {
    
}