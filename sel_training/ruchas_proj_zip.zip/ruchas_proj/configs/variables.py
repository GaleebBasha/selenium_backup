vars = {
    "url": "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login",
    "username": "Admin",
    "password": "admin123"
}